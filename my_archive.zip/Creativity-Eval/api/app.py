from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import openai
import os
import json
from typing import List, Dict
from tiktoken import encoding_for_model
import tiktoken

app = FastAPI()

# Enable CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class TextRequest(BaseModel):
    text: str

class CreativityResponse(BaseModel):
    metaphors: List[Dict[str, str]]
    sarcasm: List[Dict[str, str]]
    idioms: List[Dict[str, str]]
    creativity_score: float

def count_tokens(text: str) -> int:
    """Count tokens in text using GPT-4's tokenizer"""
    encoder = tiktoken.encoding_for_model("gpt-4")
    return len(encoder.encode(text))

async def disambiguate_element(client, text: str, type1: str, type2: str) -> str:
    response = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[
            {"role": "system", "content": f"You are a highly precise assistant that determines whether a given expression is more of a {type1} or a {type2}. Respond with exactly one word: either '{type1}' or '{type2}'."},
            {"role": "user", "content": f"Is this expression more of a {type1} or a {type2}?: {text}"}
        ],
        temperature=0
    )
    return response.choices[0].message.content.strip().lower()

@app.post("/analyze", response_model=CreativityResponse)
async def analyze_creativity(request: TextRequest):
    try:
        client = openai.OpenAI(api_key=os.getenv("OPENAI_API_KEY"))
        
        request.text = request.text.replace("\n", " ")
        print(request.text)
        # Get initial analyses
        metaphor_response = await analyze_metaphors(client, request.text)
        sarcasm_response = await analyze_sarcasm(client, request.text)
        idiom_response = await analyze_idioms(client, request.text)
        
        # Create sets of texts for comparison
        metaphor_texts = {item['text'] for item in metaphor_response}
        sarcasm_texts = {item['text'] for item in sarcasm_response}
        idiom_texts = {item['text'] for item in idiom_response}
        
        # Find overlapping elements
        metaphor_sarcasm_overlap = metaphor_texts & sarcasm_texts
        metaphor_idiom_overlap = metaphor_texts & idiom_texts
        sarcasm_idiom_overlap = sarcasm_texts & idiom_texts
        
        # Disambiguate overlapping elements
        for text in metaphor_sarcasm_overlap:
            result = await disambiguate_element(client, text, "metaphor", "sarcasm")
            if result == "sarcasm":
                metaphor_response = [m for m in metaphor_response if m['text'] != text]
            else:
                sarcasm_response = [s for s in sarcasm_response if s['text'] != text]
                
        for text in metaphor_idiom_overlap:
            result = await disambiguate_element(client, text, "metaphor", "idiom")
            if result == "idiom":
                metaphor_response = [m for m in metaphor_response if m['text'] != text]
            else:
                idiom_response = [i for i in idiom_response if i['text'] != text]
                
        for text in sarcasm_idiom_overlap:
            result = await disambiguate_element(client, text, "sarcasm", "idiom")
            if result == "idiom":
                sarcasm_response = [s for s in sarcasm_response if s['text'] != text]
            else:
                idiom_response = [i for i in idiom_response if i['text'] != text]
        
        # Calculate creativity score
        total_elements = len(metaphor_response) + len(sarcasm_response) + len(idiom_response)
        token_count = count_tokens(request.text)
        # Normalize score: (elements / tokens) * 100, capped at 100
        creativity_score = min(100, (total_elements / max(1, token_count)) * 100)
        
        return CreativityResponse(
            metaphors=metaphor_response,
            sarcasm=sarcasm_response,
            idioms=idiom_response,
            creativity_score=round(creativity_score, 2)
        )
    except Exception as e:
        print(f"Error: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

async def analyze_metaphors(client, text: str) -> List[Dict[str, str]]:
    response = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[
            {"role": "system", "content": "You are a highly precise assistant that identifies metaphors in text. For the given text, return a JSON array of objects, where each object has a 'text' field containing the metaphor found. If no metaphors are found, return an empty array."},
            {"role": "user", "content": text}
        ],
        temperature=0,
        response_format={ "type": "json_object" }
    )
    try:
        content = json.loads(response.choices[0].message.content)
        return content.get("metaphors", [])
    except json.JSONDecodeError as e:
        print(f"Error parsing metaphor response: {e}")
        return []

async def analyze_sarcasm(client, text: str) -> List[Dict[str, str]]:
    response = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[
            {"role": "system", "content": "You are a highly precise assistant that identifies sarcasm in text. For the given text, return a JSON array of objects, where each object has a 'text' field containing the sarcastic expression found. If no sarcastic expressions are found, return an empty array."},
            {"role": "user", "content": text}
        ],
        temperature=0,
        response_format={ "type": "json_object" }
    )
    try:
        content = json.loads(response.choices[0].message.content)
        return content.get("sarcasm", [])
    except json.JSONDecodeError as e:
        print(f"Error parsing sarcasm response: {e}")
        return []

async def analyze_idioms(client, text: str) -> List[Dict[str, str]]:
    response = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[
            {"role": "system", "content": "You are a highly precise assistant that identifies idiomatic expressions in text. For the given text, return a JSON array of objects, where each object has a 'text' field containing the idiomatic expression found. If no idiomatic expressions are found, return an empty array."},
            {"role": "user", "content": text}
        ],
        temperature=0,
        response_format={ "type": "json_object" }
    )
    print(response.choices[0].message.content)
    try:
        content = json.loads(response.choices[0].message.content)
        return content.get("idioms", [])
    except json.JSONDecodeError as e:
        print(f"Error parsing idiom response: {e}")
        return []

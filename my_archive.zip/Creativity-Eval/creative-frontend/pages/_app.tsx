import "@/styles/globals.css";
import type { AppProps } from "next/app";
import { PT_Serif, Poppins } from "next/font/google";

const ptSerif = PT_Serif({ 
  weight: ['400', '700'],
  subsets: ["latin"],
  variable: '--font-pt-serif',
});

const poppins = Poppins({ 
  weight: ['300', '400', '500'],
  subsets: ["latin"],
  variable: '--font-poppins',
});

export default function App({ Component, pageProps }: AppProps) {
  return (
    <main className={`${ptSerif.variable} ${poppins.variable} font-poppins font-light`}>
      <Component {...pageProps} />
    </main>
  );
}

import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Loader2, Sparkles } from "lucide-react";
import { ChangeEvent, useState } from "react";

interface AnalysisResult {
  metaphors: Array<{ text: string }>;
  sarcasm: Array<{ text: string }>;
  idioms: Array<{ text: string }>;
  creativity_score: number;
}

export default function Home() {
  const [text, setText] = useState("");
  const [loading, setLoading] = useState(false);
  const [results, setResults] = useState<AnalysisResult | null>(null);

  const analyzeText = async () => {
    if (!text.trim()) return;
    
    setLoading(true);
    try {
      const response = await fetch("http://localhost:8000/analyze", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ text }),
      });
      
      const data = await response.json();
      setResults(data);
    } catch (error) {
      console.error("Error analyzing text:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleTextChange = (e: ChangeEvent<HTMLTextAreaElement>) => {
    setText(e.target.value);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-secondary/10 p-8">
      <div className="max-w-4xl mx-auto space-y-8">
        <div className="text-center space-y-2">
          <h1 className="text-4xl font-bold tracking-tight bg-gradient-to-r from-primary to-primary/80 text-transparent bg-clip-text font-pt-serif">
            Creative Text Analyzer
          </h1>
          <p className="text-muted-foreground">
            Discover the creative elements in your text with AI-powered analysis
          </p>
        </div>

        <div className="space-y-4">
          <div className="relative">
            <Textarea
              placeholder="Enter your text here..."
              className="min-h-[200px] resize-none border-2 focus:border-primary focus:ring-primary transition-all duration-200 text-lg p-6 rounded-xl shadow-sm bg-background/90 backdrop-blur-sm"
              value={text}
              onChange={handleTextChange}
            />
            <div className="absolute bottom-4 right-4 text-muted-foreground text-sm">
              {text.length} characters
            </div>
          </div>
          <Button 
            className="w-full bg-gradient-to-r from-primary to-primary/90 hover:from-primary/90 hover:to-primary transition-all duration-300 text-lg py-6 rounded-xl shadow-md"
            onClick={analyzeText}
            disabled={loading || !text.trim()}
          >
            {loading && <Loader2 className="mr-2 h-5 w-5 animate-spin" />}
            {!loading && <Sparkles className="mr-2 h-5 w-5" />}
            {loading ? "Analyzing..." : "Analyze Text"}
          </Button>
        </div>

        {results && (
          <Card className="border-2 hover:border-primary transition-all duration-200">
            <CardHeader className="bg-secondary/5 rounded-t-lg">
              <CardTitle className="text-lg font-semibold text-primary font-pt-serif flex items-center justify-between">
                Creativity Score
                <span className="text-2xl font-bold">
                  {results.creativity_score.toFixed(1)}%
                </span>
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-4">
              <div className="w-full bg-secondary/20 rounded-full h-4">
                <div 
                  className="bg-gradient-to-r from-primary to-primary/80 h-4 rounded-full transition-all duration-500 ease-out"
                  style={{ width: `${results.creativity_score}%` }}
                />
              </div>
            </CardContent>
          </Card>
        )}

        {results && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card className="border-2 hover:border-primary transition-all duration-200">
              <CardHeader className="bg-secondary/5 rounded-t-lg">
                <CardTitle className="text-lg font-semibold text-primary font-pt-serif">Metaphors</CardTitle>
              </CardHeader>
              <CardContent className="pt-4">
                <div className="space-y-2">
                  {results.metaphors.length > 0 ? (
                    results.metaphors.map((item, index) => (
                      <Badge 
                        key={index} 
                        variant="secondary" 
                        className="mr-2 mb-2 bg-primary/10 text-primary hover:bg-primary/20 transition-colors font-normal"
                      >
                        {item.text}
                      </Badge>
                    ))
                  ) : (
                    <p className="text-sm text-muted-foreground">No metaphors found</p>
                  )}
                </div>
              </CardContent>
            </Card>

            <Card className="border-2 hover:border-primary transition-all duration-200">
              <CardHeader className="bg-secondary/5 rounded-t-lg">
                <CardTitle className="text-lg font-semibold text-primary font-pt-serif">Sarcasm</CardTitle>
              </CardHeader>
              <CardContent className="pt-4">
                <div className="space-y-2">
                  {results.sarcasm.length > 0 ? (
                    results.sarcasm.map((item, index) => (
                      <Badge 
                        key={index} 
                        variant="secondary" 
                        className="mr-2 mb-2 bg-primary/10 text-primary hover:bg-primary/20 transition-colors font-normal"
                      >
                        {item.text}
                      </Badge>
                    ))
                  ) : (
                    <p className="text-sm text-muted-foreground">No sarcasm found</p>
                  )}
                </div>
              </CardContent>
            </Card>

            <Card className="border-2 hover:border-primary transition-all duration-200">
              <CardHeader className="bg-secondary/5 rounded-t-lg">
                <CardTitle className="text-lg font-semibold text-primary font-pt-serif">Idioms</CardTitle>
              </CardHeader>
              <CardContent className="pt-4">
                <div className="space-y-2">
                  {results.idioms.length > 0 ? (
                    results.idioms.map((item, index) => (
                      <Badge 
                        key={index} 
                        variant="secondary" 
                        className="mr-2 mb-2 bg-primary/10 text-primary hover:bg-primary/20 transition-colors font-normal"
                      >
                        {item.text}
                      </Badge>
                    ))
                  ) : (
                    <p className="text-sm text-muted-foreground">No idioms found</p>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
}
